void IrInit();
int IR_sensor();