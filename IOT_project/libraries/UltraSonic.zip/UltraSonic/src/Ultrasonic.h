void UltraSPinMode();
void Ultrasonic();