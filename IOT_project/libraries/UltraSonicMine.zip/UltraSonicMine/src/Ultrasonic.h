long Ultrasonic();
void UltraSInit();
