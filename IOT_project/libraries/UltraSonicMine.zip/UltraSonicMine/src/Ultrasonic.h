void Ultrasonic();
void UltraSInit();