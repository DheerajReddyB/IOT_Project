void TiltInit();
long Tilt();